</div>
<!-- konten -->
<footer>
<p>Copyright © 2019 | SMKN 7
BALEENDAH</p>
</footer>

</body>
</html>
